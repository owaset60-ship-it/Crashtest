

//contact details
global.ownernomer = "01213773805"
global.dev = ["01213773805","01213773805"]
global.ownername = "𝐎𝐖𝐀𝐒𝐄𝐓 𝐂𝐑𝐀𝐒𝐇"
global.ytname = "𝐎𝐖𝐀𝐒𝐄𝐓 𝐂𝐑𝐀𝐒𝐇"
global.socialm = "GitHub: 𝐎𝐖𝐀𝐒𝐄𝐓 𝐂𝐑𝐀𝐒𝐇"
global.location = "Egypt, Alexandria, sidigiber"

global.ownernumber = '01213773805'  //creator number
global.ownername = '𝐎𝐖𝐀𝐒𝐄𝐓 𝐂𝐑𝐀𝐒𝐇' //owner name
global.botname = 'Bot Crash  v1 ' //name of the bot

//sticker details
global.packname = '\n\n\n\n\n\n\nSticker By'
global.author = '𝐎𝐖𝐀𝐒𝐄𝐓 𝐂𝐑𝐀𝐒𝐇⚉\n\nContact: 01213773805'

//console view/theme
global.themeemoji = '🪀'
global.wm = "𝐎𝐖𝐀𝐒𝐄𝐓"

//theme link
global.link = 'https://t.me/owaset_cr'
global.idch = '120363422217202244@newsletter'

global.baileysDB = 'baileysDB.json'
global.botDb = 'database.json'

//prefix
global.prefa = ['','!','.',',','🐤','🗿'] 

global.limitawal = {
    premium: "Infinity",
    free: 20
}

//menu type 
//v1 is image menu, 
//v2 is link + image menu,
//v3 is video menu,
//v4 is call end menu
global.typemenu = 'v1'

// Global Respon
global.mess = {
    success: 'Done✓',
    admin: `\`[ # ]\` This Command Can Only Be Used By Group Admins !`,
    botAdmin: `\`[ # ]\` This Command Can Only Be Used When Bot Becomes Group Admin !`,
    OnlyOwner: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nTelegram: @owaset\nWhatsApp: +201213773805`,
    OnlyGrup: `\`[ # ]\` This Command Can Only Be Used In Group Chat !`,
    private: `\`[ # ]\` This Command Can Only Be Used In Private Chat !`,
    wait: `\`[ # ]\` Wait Wait a minute`,
    notregist: `\`[ # ]\` You are not registered in the Bot Database. Please register first.`,
    premium: `\`[ # ]\` This Command Can Only Be Used By Premium User ! \n\nWant Premium? Chat Developer.\nYouTube: @owaset\nTelegram:@owaset \nWhatsApp: +201213773805`,
}

// ملف config.js
module.exports = {
    banner: [
        "01213773805@s.whatsapp.net",
        "20@s.whatsapp.net",
        "01213773805@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net",
        "20@s.whatsapp.net"
    ]
};

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})